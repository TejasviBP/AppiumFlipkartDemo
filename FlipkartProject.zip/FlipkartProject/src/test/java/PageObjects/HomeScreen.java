package PageObjects;

import org.openqa.selenium.By;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;


public class HomeScreen {

public AndroidDriver<AndroidElement> driver;
	
	public HomeScreen(AndroidDriver<AndroidElement> driver) {
		this.driver=driver;
	}
	
	
	By logo = By.xpath("//android.widget.Image[@text='FKLite-a92880']");
	
	
	public AndroidElement getLogo() {
		return driver.findElement(logo);
	}


}
