package PageObjects;

import org.openqa.selenium.By;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class Checkout {
public AndroidDriver<AndroidElement> driver;
	
	public Checkout(AndroidDriver<AndroidElement> driver) {
		this.driver=driver;
	}
	//android.widget.Image[@index='0']
	By myCart= By.xpath("//android.view.View[@text='My Cart']");
	By pincode = By.xpath("//android.view.View[@text='Enter Delivery Pincode']");
	By typePincode= By.xpath("//android.widget.EditText[@index='0']");
	By submit= By.xpath("//android.view.View[@text='Submit']");
	By noOfItemTest= By.xpath("//android.view.View[@text='Flipkart (1)']");
	By placeOrder  = By.xpath("//android.view.View[@text='Place Order']");
    By afterPlaceOrderText=By.xpath("//android.view.View[@text='Log in to complete your shopping']"); 
	
	///
    public AndroidElement getTextAfterOrder() {
		return driver.findElement(afterPlaceOrderText);
	}
	public AndroidElement myCartText() {
		return driver.findElement(myCart);
	}
	public AndroidElement clickOnSubmit() {
		return driver.findElement(submit);
	}
	public AndroidElement typePincodeInBox() {
		return driver.findElement(typePincode);
	}
	public AndroidElement getPincode() {
		return driver.findElement(pincode);
	}

	public AndroidElement itemInCart() {
		return driver.findElement(noOfItemTest);
	}
	public AndroidElement clickCheckoutBtn() {
		return driver.findElement(placeOrder);
	}
	
	
	
}
