package PageObjects;

import org.openqa.selenium.By;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;

public class AddProductToCart {

public AndroidDriver<AndroidElement> driver;
	
	public AddProductToCart(AndroidDriver<AndroidElement> driver) {
		this.driver=driver;
	}
	
	
	By searchBox =By.xpath("//android.view.View[@content-desc='Search for Products, Brands and More']");
	By mobiles= By.xpath("//android.widget.Image[@content-desc='mobiles']");
	By firstElement=By.xpath("//android.view.View[@text='POCO C31 (Royal Blue, 64 GB)']");
	By addToCart= By.xpath("//android.view.View[@content-desc='ADD TO CART']");
	By text2= By.xpath("//android.view.View[@content-desc='GO TO CART']");
	By logo = By.xpath("//android.widget.Image[@text='FKLite-a92880']");
	
	
	public AndroidElement getLogo() {
		return driver.findElement(logo);
	}
	public AndroidElement clickFirstElement() {
		return driver.findElement(firstElement);
	}
	public AndroidElement getSearch() {
		return driver.findElement(searchBox);
	}
	public AndroidElement enterMobiles() {
		return driver.findElement(mobiles);
	}
	public AndroidElement ClickToAdd() {
		return driver.findElement(addToCart);
	}
	public AndroidElement getAddedText() {
		return driver.findElement(text2);
	}
	
}
