package PageObjects;

import org.openqa.selenium.By;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;


public class LoginPage {
	
	public AndroidDriver<AndroidElement> driver;

	public LoginPage(AndroidDriver<AndroidElement> driver) {
		this.driver=driver;
	}
	
	
	By clickLogin = By.xpath("//android.view.View[@text='Login']");
	By mobile= By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[1]/android.view.View[2]/android.view.View[3]/android.view.View/android.view.View[3]");
	By useEmailID = By.xpath("//android.view.View[@content-desc='Use Email-ID']");
	By enterEmail = By.xpath("//android.widget.EditText[@content-desc='Email ID']");
	By continueBtn  = By.xpath("//android.widget.Button[@content-desc='Continue']");
	By password = By.xpath("//android.webkit.WebView[@content-desc='Flipkart']/android.view.View[2]/android.widget.EditText");
	By text = By.xpath("//android.view.View[@text='Log in for the best experience']");

	
	///
	public AndroidElement getClickLogin() {
		return driver.findElement(clickLogin);
	}

	public AndroidElement enterMobile() {
		return driver.findElement(mobile);
	}
	public AndroidElement ClickOnEmailID() {
		return driver.findElement(useEmailID);
	}
	public AndroidElement enterEmailId() {
		return driver.findElement(enterEmail);
	}
	public AndroidElement getText() {
		return driver.findElement(text);
	}
	
	public AndroidElement clickContinue() {
		return driver.findElement(continueBtn);
	}
	
}
