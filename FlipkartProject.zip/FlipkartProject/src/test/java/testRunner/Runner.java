package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)

@CucumberOptions(publish = true,
		features = "src/test/resources/Feature",
		glue= {"StepDefinations","hooks"}, monochrome = true,tags="@flipkartTest",
		plugin= {"pretty","html:target/cucumber.html","json:target/cucumber.json","junit:target/cukes.xml"})
public class Runner {

}
