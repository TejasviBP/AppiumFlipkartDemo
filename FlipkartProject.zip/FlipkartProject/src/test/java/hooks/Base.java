package hooks;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Base {
	public static AndroidDriver<AndroidElement> driver;
	
	
	public void launchApp() throws MalformedURLException {

		DesiredCapabilities capability= new DesiredCapabilities();
		System.out.println("Configuring capabilities");
		capability.setCapability("deviceName", "AOSP on IA Emulator");  
		capability.setCapability("udid", "emulator-5554");
		capability.setCapability("platformName", "Android");
		capability.setCapability("platformVersion", "9.0");
		//  /
		capability.setCapability("appPackage", "com.flipapp.flipkartlite");
		capability.setCapability("appActivity", "com.flipapp.flipkartlite.MainActivity");
		capability.setCapability("automationName", "UiAutomator2");
		capability.setCapability("newCommandTimeout", "1200");
		System.out.println("Starting  Flipkart Applications");
		driver= new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capability);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Execution successful");
	}
	

	public void tearDown() {
		driver.quit();
	}
	
	public static AndroidDriver<AndroidElement> getDriver() {
		return driver;
	}
}