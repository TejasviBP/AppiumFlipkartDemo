package StepDefinations;

import java.net.MalformedURLException;

import org.junit.Assert;

import PageObjects.AddProductToCart;
import PageObjects.Checkout;
import hooks.Base;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class AddToCart_Step {
	private AndroidDriver<AndroidElement> driver;

	AddProductToCart cart= new AddProductToCart(driver);;
	Base base= new Base();

	@BeforeStep(value = "@flipkartTest")
	public void setUp() throws MalformedURLException {
		base.launchApp();
	}

	public AddToCart_Step() {
		this.driver = Base.getDriver();
	}

	@Given("^homescreen is visible$")
	public void homescreen_Is_Visible() throws Throwable {

		if(cart.getLogo().isDisplayed()) {
			System.out.println("Homescreen is visible");
		}
		else {
			System.out.println("Homescreen is not visible");
		}
	}
	@Then("^click on searchBox$")
	public void  click_On_SearchBox() throws Throwable {
		cart.getSearch().click();

	}
	@And("^search for Mobiles$")
	public void  search_For_Mobiles() throws Throwable {
		cart.getSearch().sendKeys("Mobiles");
		cart.getSearch().submit();
	}
	@Then("^click on first mobile$")
	public void  click_On_First_Mobile() throws Throwable {
		cart.clickFirstElement().click();
	}
	@And("^add to cart$")
	public void  add_To_Cart() throws Throwable {
		cart.ClickToAdd().click();
	}
	@Then("^validate text Go To Cart$")
	public void  validate_Text_Go_To_Cart() throws Throwable {

		String text= cart.getAddedText().getText();	
		Assert.assertEquals(text, "Go To Cart");
		cart.getAddedText().click();
	}

	Checkout check= new Checkout(driver);

	@Given("^my cart is visible$")
	public void  my_cart_is_visible() throws Throwable {
		if(check.myCartText().isDisplayed()) {
			System.out.println("cart is open");
		}else {
			System.out.println("cart is not open start again");
		}
	}
	@And("^get number of items in cart$")
	public void  get_number_of_items_in_cart() throws Throwable {
		String s= check.itemInCart().getText();
		System.out.println("Total number of items in cart: "+s);

	}
	@Then("^click on pincode$")
	public void  click_on_pincode() throws Throwable {
		check.getPincode().click();
		Thread.sleep(3000);
	}
	@And("^enter pincode$")
	public void  enter_Pincode() throws Throwable {
		check.typePincodeInBox().sendKeys("431001");
		check.typePincodeInBox().submit();
		Thread.sleep(3000);
	}
	@Then("^click on place order$")
	public void   click_on_place_order() throws Throwable {
		check.clickCheckoutBtn().click();
	}
	@And("^validate text$")
	public void  Validate_Continue_Text() throws Throwable {
		String str= check.getTextAfterOrder().getText();
		System.out.println(str);
		System.out.println("Checkout successful");
	}
	@AfterStep
	public void tearDown() throws Exception {
		base.tearDown();
	}

}
