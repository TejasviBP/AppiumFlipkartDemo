package StepDefinations;

import java.net.MalformedURLException;

import PageObjects.HomeScreen;
import PageObjects.LoginPage;
import hooks.Base;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.Given;

public class Homescreen_Step {
	private AndroidDriver<AndroidElement> driver;
	//deals_POM dp;
	HomeScreen home= new HomeScreen(driver);;
	Base base= new Base();
	@BeforeStep(value = "@flipkartTest")
	public void setUp() throws MalformedURLException {
		base.launchApp();
	}
	public Homescreen_Step() {
		this.driver = Base.getDriver();
	}

	@Given("^I validate homescreen$")
	public void I_Validate_Homescreen() throws Throwable {

		if(home.getLogo().isDisplayed()) {
			System.out.println("Homescreen is visible");
		}
		else {
			System.out.println("Homescreen is not visible");
		}
	}
	@AfterStep
	public void tearDown() throws Exception {
		base.tearDown();
	}

}
