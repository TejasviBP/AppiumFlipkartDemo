package StepDefinations;


import java.net.MalformedURLException;

import PageObjects.LoginPage;
import hooks.Base;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;



public class Login_Step {
	private AndroidDriver<AndroidElement> driver;

	LoginPage login= new LoginPage(driver);;
	Base base= new Base();
	@BeforeStep(value = "@flipkartTest")
	public void setUp() throws MalformedURLException {
		base.launchApp();
	}
	public Login_Step() {
		this.driver = Base.getDriver();
	}

	@Given("^validate login$")
	public void validate_Login() throws Throwable {

		login= new LoginPage(driver);
		if(login.getClickLogin().isDisplayed()) {
			System.out.println("Homescreen is visible");
		}
		else {
			System.out.println("Homescreen is not visible");
		}
	}

	@Then("^click MobileField$")
	public void enter_Valid_emailID() throws Throwable {
		login.enterMobile().click();
	}
	@And("^validate Text$")
	public void validate_Text() throws Throwable {
		if(login.getText().isDisplayed()) {
			System.out.println("Login is not possible , but Text is visible");
		}else {
			System.out.println("Login is not possible and Text also not visible");
		}

	}
	@Then("^navigate back to homeScreen$")
	public void navigate_Back_To_HomeScreen()throws Throwable {
		driver.navigate().back();
		driver.navigate().back();
		login.getClickLogin().click();
	}

	@AfterStep
	public void tearDown() throws Exception {
		base.tearDown();
	}


}


